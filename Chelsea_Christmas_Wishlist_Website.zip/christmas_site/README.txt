CHELSEA'S CHRISTMAS WISH LIST — GITHUB PAGES

1. Create a public repository on GitHub named christmas-wishlist.
2. Add/upload index.html to the repository root, commit changes.
3. In Settings > Pages, choose Deploy from a branch, main, / (root), and Save.
4. Your site will appear at https://YOUR-USERNAME.github.io/christmas-wishlist/

LIVE GOOGLE SHEETS SYNC
The site is already configured for your spreadsheet ID and Christmas wishlist tab.
In Google Sheets: File > Share > Publish to web > select 'Christmas wishlist' tab > CSV > Publish.
The site attempts to load the CSV when visitors open it. The sheet's published data is public, so do not add private information.
If the live feed is unavailable, the site shows the saved 10-item snapshot and an explanatory message.

IMPORTANT: Google Sheets public CSV access may require the spreadsheet to be shared/published appropriately. Google Sheets updates may be cached briefly by Google. The site's fallback snapshot will not automatically include new entries if CSV is unavailable.

COLUMNS: Category, Gift idea, Store, Preferences / notes, Est. price, Product URL, Shop.
Keep those headers in the sheet and new gifts below them.
